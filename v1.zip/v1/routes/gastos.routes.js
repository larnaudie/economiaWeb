import express from "express";
import {
    obtenerGastos,
    obtenerGastoPorId,
    actualizarGasto,
    eliminarGasto,
    crearGasto,
    crearGastosBulk,
    actualizarGastosBulk,
    actualizarOrdenGastosCuenta,
    eliminarTodosLosGastos
} from "../controllers/gastos.controller.js";
import {
    gastoSchema,
    gastosBulkSchema,
    gastosBulkUpdateSchema,
    gastoUpdateSchema
} from "../validators/gasto.validators.js";
import { validateBody } from "../middlewares/validateBody.middleware.js";

const router = express.Router({ mergeParams: true });

//Peticiones a /v1/gastos
router.post("/", validateBody(gastoSchema), crearGasto)
router.get("/", obtenerGastos)
router.patch("/orden-cuenta", actualizarOrdenGastosCuenta);
router.delete("/eliminar-todo", eliminarTodosLosGastos);
router.get("/:id", obtenerGastoPorId)
router.patch("/:id", validateBody(gastoUpdateSchema), actualizarGasto);
router.delete("/:id", eliminarGasto)
router.post("/bulk", validateBody(gastosBulkSchema), crearGastosBulk);
router.patch("/bulk", validateBody(gastosBulkUpdateSchema), actualizarGastosBulk);
export default router;